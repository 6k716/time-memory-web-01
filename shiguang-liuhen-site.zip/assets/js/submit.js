(function () {
  'use strict';

  var Store = window.TraceStore;
  var UI = window.TraceUI;

  var form = document.getElementById('wishForm');
  if (!form) return;

  var params = new URLSearchParams(window.location.search);
  var editing = Store.getById(params.get('id'));
  var currentStep = 1;
  var draftTimer = null;
  var submitted = false;

  var stepRail = document.getElementById('stepRail');
  var draftBar = document.getElementById('draftBar');
  var draftStatus = document.getElementById('draftStatus');
  var draftSave = document.getElementById('draftSave');
  var draftClear = document.getElementById('draftClear');
  var submitBtn = document.getElementById('submitBtn');
  var successPanel = document.getElementById('successPanel');
  var successTitle = document.getElementById('successTitle');
  var successHeading = document.getElementById('successHeading');
  var successMessage = document.getElementById('successMessage');
  var successDetail = document.getElementById('successDetail');
  var successAgain = document.getElementById('successAgain');
  var formLayout = document.querySelector('.form-layout');
  var formAside = document.querySelector('.form-aside');
  var storyCount = document.getElementById('storyCount');
  var wishCount = document.getElementById('wishCount');

  if (params.get('id') && !editing) {
    UI.toast('没有找到要修改的心愿，已切换到新建模式', 'error');
  }

  function fieldOf(name) {
    return form.querySelector('[data-field="' + name + '"]');
  }

  function showError(name, message) {
    var field = fieldOf(name);
    if (!field) return;
    field.classList.add('has-error');
    var error = field.querySelector('.error');
    if (error) error.textContent = message;
  }

  function clearError(name) {
    var field = fieldOf(name);
    if (!field) return;
    field.classList.remove('has-error');
    var error = field.querySelector('.error');
    if (error) error.textContent = '';
  }

  function clearAllErrors() {
    form.querySelectorAll('.field.has-error').forEach(function (field) {
      field.classList.remove('has-error');
    });
    form.querySelectorAll('.error').forEach(function (node) {
      node.textContent = '';
    });
  }

  function focusFirstError() {
    var node = form.querySelector('.field.has-error input, .field.has-error select, .field.has-error textarea');
    if (node) {
      try {
        node.focus({ preventScroll: false });
      } catch (error) {
        node.focus();
      }
    }
  }

  function validateStep(step) {
    var valid = true;
    if (step === 1) {
      var authorName = form.elements.authorName.value.trim();
      if (!authorName) {
        showError('authorName', '请留下一个称呼，或开启匿名展示。');
        valid = false;
      } else if (authorName.length > 24) {
        showError('authorName', '称呼请控制在 24 个字以内。');
        valid = false;
      }
    }
    if (step === 2) {
      var title = form.elements.title.value.trim();
      var story = form.elements.story.value.trim();
      var wish = form.elements.wish.value.trim();
      if (title.length < 2) {
        showError('title', '标题至少需要 2 个字，方便日后找到它。');
        valid = false;
      }
      if (story.length < 30) {
        showError('story', '故事至少需要 30 个字，现在写了 ' + story.length + ' 个字。');
        valid = false;
      }
      if (wish.length < 10) {
        showError('wish', '再写长一点吧，至少 10 个字。');
        valid = false;
      }
    }
    if (step === 3) {
      if (!form.elements.consent.checked) {
        showError('consent', '请先确认你了解这是展示原型，数据只保存在本机。');
        valid = false;
      }
    }
    return valid;
  }

  function updateRail() {
    if (!stepRail) return;
    stepRail.querySelectorAll('.rail-item').forEach(function (item) {
      var index = Number(item.getAttribute('data-rail'));
      item.classList.toggle('is-active', index === currentStep);
      item.classList.toggle('is-done', index < currentStep);
    });
  }

  function jumpTo(step, skipScroll) {
    currentStep = step;
    form.querySelectorAll('.form-step').forEach(function (panel) {
      panel.classList.toggle('is-active', Number(panel.getAttribute('data-step')) === step);
    });
    updateRail();
    if (skipScroll) return;
    var target = document.querySelector('.form-panel');
    if (target) {
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    }
  }

  function goTo(step) {
    if (step > currentStep && !validateStep(currentStep)) {
      focusFirstError();
      return;
    }
    jumpTo(step);
  }

  function collect() {
    return {
      authorName: form.elements.authorName.value.trim(),
      relation: form.elements.relation.value || '本人',
      title: form.elements.title.value.trim(),
      category: form.elements.category.value || '想说的话',
      story: form.elements.story.value.trim(),
      wish: form.elements.wish.value.trim(),
      burialRegion: form.elements.burialRegion.value.trim(),
      burialType: form.elements.burialType.value || '尚未决定',
      burialNote: form.elements.burialNote.value.trim(),
      visibility: form.elements.visibility.value || 'private',
      anonymous: form.elements.anonymous.checked
    };
  }

  function setValue(name, value) {
    var element = form.elements[name];
    if (element && typeof element.value !== 'undefined' && element.type !== 'checkbox') {
      element.value = value == null ? '' : value;
    }
  }

  function setRadio(name, value) {
    var inputs = form.querySelectorAll('input[name="' + name + '"]');
    if (!inputs.length || !value) return;
    inputs.forEach(function (input) {
      input.checked = input.value === value;
    });
  }

  function fillForm(data) {
    if (!data) return;
    ['authorName', 'relation', 'title', 'story', 'wish', 'burialRegion', 'burialType', 'burialNote'].forEach(function (name) {
      setValue(name, data[name]);
    });
    setRadio('category', data.category);
    setRadio('visibility', data.visibility || 'private');
    if (form.elements.anonymous) form.elements.anonymous.checked = Boolean(data.anonymous);
    updateCounters();
  }

  function updateCounters() {
    if (storyCount) storyCount.textContent = String(form.elements.story.value.length);
    if (wishCount) wishCount.textContent = String(form.elements.wish.value.length);
  }

  function setDraftStatus(text) {
    if (draftStatus) draftStatus.textContent = text;
  }

  function saveDraftNow(quiet) {
    if (editing || submitted) return;
    var data = collect();
    if (!data.authorName && !data.title && !data.story && !data.wish) {
      if (!quiet) UI.toast('还没有可以暂存的内容');
      return;
    }
    var saved = Store.saveDraft(data);
    if (!saved) {
      if (!quiet) UI.toast('浏览器阻止了本地存储，草稿未能保存', 'error');
      return;
    }
    setDraftStatus('草稿已保存 · ' + UI.timeLabel(saved.savedAt));
    if (draftClear) draftClear.hidden = false;
    if (!quiet) UI.toast('草稿已暂存到本机');
  }

  function scheduleDraft() {
    if (editing || submitted) return;
    window.clearTimeout(draftTimer);
    draftTimer = window.setTimeout(function () {
      saveDraftNow(true);
    }, 700);
  }

  function showSuccess(wish, isEdit) {
    submitted = true;
    form.hidden = true;
    if (draftBar) draftBar.hidden = true;
    if (formAside) formAside.hidden = true;
    if (formLayout) formLayout.classList.add('is-success');
    if (successPanel) successPanel.hidden = false;
    if (successTitle) successTitle.textContent = wish.title;
    if (successHeading) successHeading.textContent = isEdit ? '修改已经保存。' : '心愿已经留在这里。';
    if (successMessage) {
      successMessage.textContent = isEdit
        ? '新的内容已写入本机档案，原有的登记时间与点亮次数保持不变。'
        : '它只保存在你的浏览器中。你可以继续补充，也可以去档案里看看它。';
    }
    if (successDetail) successDetail.href = 'detail.html?id=' + encodeURIComponent(wish.id);
    if (successAgain) successAgain.hidden = isEdit;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  }

  function resetForNew() {
    submitted = false;
    form.reset();
    clearAllErrors();
    updateCounters();
    if (form) form.hidden = false;
    if (draftBar) draftBar.hidden = false;
    if (formAside) formAside.hidden = false;
    if (formLayout) formLayout.classList.remove('is-success');
    if (successPanel) successPanel.hidden = true;
    if (draftClear) draftClear.hidden = true;
    setDraftStatus('草稿会随时保存在本机');
    jumpTo(1, true);
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  }

  if (editing) {
    fillForm(editing);
    var heading = document.getElementById('formHeading');
    var lead = document.getElementById('formLead');
    if (heading) heading.textContent = '把这份心愿，再想一想。';
    if (lead) lead.textContent = '修改会直接保存到当前浏览器，原登记时间与点亮次数保持不变。';
    if (submitBtn) submitBtn.textContent = '保存修改';
    if (draftBar) draftBar.hidden = true;
    if (successAgain) successAgain.hidden = true;
    document.title = '修改心愿 · 时光留痕';
    var back = document.querySelector('main .back-link');
    if (back) back.href = 'detail.html?id=' + encodeURIComponent(editing.id);
  } else {
    var draft = Store.getDraft();
    if (draft) {
      fillForm(draft);
      setDraftStatus('已恢复上次未完成的草稿 · ' + UI.timeLabel(draft.savedAt));
      if (draftClear) draftClear.hidden = false;
    }
  }

  updateCounters();
  jumpTo(1, true);

  form.querySelectorAll('[data-next]').forEach(function (button) {
    button.addEventListener('click', function () {
      goTo(Number(button.getAttribute('data-next')));
    });
  });

  form.querySelectorAll('[data-prev]').forEach(function (button) {
    button.addEventListener('click', function () {
      jumpTo(Number(button.getAttribute('data-prev')));
    });
  });

  form.addEventListener('input', function (event) {
    var target = event.target;
    if (target && target.closest('[data-field]')) {
      clearError(target.closest('[data-field]').getAttribute('data-field'));
    }
    updateCounters();
    scheduleDraft();
  });

  form.addEventListener('change', function (event) {
    var target = event.target;
    if (target && target.closest('[data-field]')) {
      clearError(target.closest('[data-field]').getAttribute('data-field'));
    }
    scheduleDraft();
  });

  form.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter') return;
    var tag = event.target.tagName;
    var type = (event.target.getAttribute('type') || '').toLowerCase();
    if (tag === 'INPUT' && (type === 'text' || type === 'search')) {
      event.preventDefault();
      if (currentStep < 3) goTo(currentStep + 1);
    }
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    if (!validateStep(1)) {
      jumpTo(1);
      focusFirstError();
      return;
    }
    if (!validateStep(2)) {
      jumpTo(2);
      focusFirstError();
      return;
    }
    if (!validateStep(3)) {
      focusFirstError();
      return;
    }

    var data = collect();
    if (editing) {
      data.id = editing.id;
      data.createdAt = editing.createdAt;
      data.lights = editing.lights;
      data.favorite = editing.favorite;
    }
    var saved = Store.save(data);
    Store.clearDraft();
    showSuccess(saved, Boolean(editing));
  });

  if (draftSave) {
    draftSave.addEventListener('click', function () {
      saveDraftNow(false);
    });
  }

  if (draftClear) {
    draftClear.addEventListener('click', function () {
      Store.clearDraft();
      draftClear.hidden = true;
      setDraftStatus('草稿已清空');
      UI.toast('本机草稿已清空');
    });
  }

  if (successAgain) {
    successAgain.addEventListener('click', resetForNew);
  }

  window.addEventListener('beforeunload', function () {
    if (editing || submitted) return;
    var data = collect();
    if (data.authorName || data.title || data.story || data.wish) {
      Store.saveDraft(data);
    }
  });
})();