(function () {
  'use strict';

  var revealObserver = null;
  var toastTimer = null;

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  function toast(message, type) {
    var stack = document.querySelector('.toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'toast-stack';
      stack.setAttribute('role', 'status');
      stack.setAttribute('aria-live', 'polite');
      document.body.appendChild(stack);
    }
    var node = document.createElement('div');
    node.className = 'toast' + (type === 'error' ? ' is-error' : '');
    node.textContent = message;
    stack.appendChild(node);
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      node.classList.add('is-out');
      window.setTimeout(function () {
        node.remove();
      }, 320);
    }, 3200);
  }

  function confirmAction(options) {
    var settings = Object.assign(
      {
        title: '确认操作',
        message: '',
        confirmText: '确认',
        cancelText: '取消',
        danger: false
      },
      options || {}
    );

    return new Promise(function (resolve) {
      if (typeof HTMLDialogElement === 'undefined' || !HTMLDialogElement.prototype.showModal) {
        resolve(window.confirm(settings.title + '\n\n' + settings.message));
        return;
      }

      var dialog = document.createElement('dialog');
      dialog.className = 'dialog';
      dialog.setAttribute('aria-labelledby', 'dialogTitle');
      dialog.setAttribute('aria-describedby', 'dialogMessage');
      dialog.innerHTML =
        '<div class="dialog-inner">' +
        '<h2 class="dialog-title" id="dialogTitle"></h2>' +
        '<p class="dialog-message" id="dialogMessage"></p>' +
        '<div class="dialog-actions">' +
        '<button type="button" class="btn btn-ghost" data-role="cancel"></button>' +
        '<button type="button" class="btn btn-primary" data-role="ok"></button>' +
        '</div>' +
        '</div>';

      dialog.querySelector('.dialog-title').textContent = settings.title;
      dialog.querySelector('.dialog-message').textContent = settings.message;
      var cancelBtn = dialog.querySelector('[data-role="cancel"]');
      var okBtn = dialog.querySelector('[data-role="ok"]');
      cancelBtn.textContent = settings.cancelText;
      okBtn.textContent = settings.confirmText;
      if (settings.danger) okBtn.classList.add('btn-danger');

      var settled = false;
      function finish(result) {
        if (settled) return;
        settled = true;
        if (dialog.open) dialog.close();
        dialog.remove();
        resolve(result);
      }

      okBtn.addEventListener('click', function () {
        finish(true);
      });
      cancelBtn.addEventListener('click', function () {
        finish(false);
      });
      dialog.addEventListener('cancel', function (event) {
        event.preventDefault();
        finish(false);
      });
      dialog.addEventListener('click', function (event) {
        if (event.target === dialog) finish(false);
      });

      document.body.appendChild(dialog);
      dialog.showModal();
      okBtn.focus();
    });
  }

  function initNav() {
    var nav = document.getElementById('siteNav');
    var toggle = document.getElementById('navToggle');
    var links = document.getElementById('navLinks');

    if (toggle && links) {
      toggle.addEventListener('click', function () {
        var open = links.classList.toggle('is-open');
        toggle.classList.toggle('is-active', open);
        toggle.setAttribute('aria-expanded', String(open));
      });
      links.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          links.classList.remove('is-open');
          toggle.classList.remove('is-active');
          toggle.setAttribute('aria-expanded', 'false');
        });
      });
      document.addEventListener('click', function (event) {
        if (!links.classList.contains('is-open')) return;
        if (links.contains(event.target) || toggle.contains(event.target)) return;
        links.classList.remove('is-open');
        toggle.classList.remove('is-active');
        toggle.setAttribute('aria-expanded', 'false');
      });
    }

    if (nav) {
      var onScroll = function () {
        nav.classList.toggle('is-scrolled', window.scrollY > 8);
      };
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }

    var page = document.body.getAttribute('data-page');
    document.querySelectorAll('[data-nav]').forEach(function (link) {
      if (link.getAttribute('data-nav') === page) link.classList.add('is-active');
    });
  }

  function initReveal(root) {
    var scope = root || document;
    var targets = Array.prototype.slice.call(scope.querySelectorAll('.reveal:not(.is-visible)'));
    if (!targets.length) return;

    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      targets.forEach(function (node) {
        node.classList.add('is-visible');
      });
      return;
    }

    if (!revealObserver) {
      revealObserver = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12, rootMargin: '0px 0px -6% 0px' }
      );
    }

    targets.forEach(function (node) {
      revealObserver.observe(node);
    });
  }

  function initYear() {
    document.querySelectorAll('[data-year]').forEach(function (node) {
      node.textContent = String(new Date().getFullYear());
    });
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      var area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      try {
        var ok = document.execCommand('copy');
        area.remove();
        ok ? resolve() : reject(new Error('复制失败'));
      } catch (error) {
        area.remove();
        reject(error);
      }
    });
  }

  function download(filename, content) {
    var blob = new Blob([content], { type: 'application/json;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 1000);
  }

  function pad(value) {
    return String(value).padStart(2, '0');
  }

  function timeLabel(iso) {
    var date = new Date(iso);
    if (isNaN(date.getTime())) return '';
    return pad(date.getHours()) + ':' + pad(date.getMinutes());
  }

  ready(function () {
    initNav();
    initReveal();
    initYear();
  });

  window.TraceUI = {
    toast: toast,
    confirm: confirmAction,
    initReveal: initReveal,
    copyText: copyText,
    download: download,
    timeLabel: timeLabel
  };
})();