(function () {
  'use strict';

  var KEY = 'shiguang.wishes.v1';
  var DRAFT_KEY = 'shiguang.draft.v1';
  var LIGHTS_KEY = 'shiguang.lights.v1';
  var VERSION = 1;

  var CATEGORIES = ['安葬心愿', '身后事务', '纪念方式', '想说的话'];
  var RELATIONS = ['本人', '配偶', '子女', '父母', '亲友', '其他'];
  var BURIAL_TYPES = ['尚未决定', '故乡故土', '自然山海', '纪念林 / 树葬', '城市公墓', '其他'];
  var VISIBILITY = {
    public: { label: '公开展示', short: '公开', hint: '会出现在首页与心愿档案中' },
    family: { label: '家人可见', short: '家人可见', hint: '仅在家人范围内留存与查看' },
    private: { label: '仅自己可见', short: '仅自己', hint: '作为私人记录，不对外展示' }
  };

  var memory = null;

  function nowISO() {
    return new Date().toISOString();
  }

  function uid() {
    return 'wish_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
  }

  function clean(value) {
    return String(value == null ? '' : value).replace(/\r\n/g, '\n').trim();
  }

  function seedWishes() {
    return [
      {
        id: 'wish_seed_hai',
        title: '把最后一段路，交给海风',
        category: '安葬心愿',
        authorName: '林见秋',
        relation: '本人',
        anonymous: false,
        story:
          '我在海岛长大，后来在城里教了三十四年地理。退休以后，每年秋天还是会回嵊泗住一阵子。\n\n我和老周年轻时最喜欢在傍晚沿着防波堤散步，看渔船一盏一盏亮起来。他走得早，骨灰已经撒在了那片海。我跟女儿说过很多次，不要买墓地，不要立碑，也不想麻烦亲戚朋友从各地赶回来。\n\n如果那一天到了，挑个风浪小的早晨，把我带到嵊泗以东的海面。你们可以带一束白色的小花，也可以什么都不带。撒完以后不必立刻离开，坐一会儿，吃碗海鲜面，再各自回家。\n\n我没有别的交代。想我的时候去海边走走，不用特意准备什么。带一颗橘子也行，我从前最爱坐在礁石上剥橘子。',
        wish:
          '不要冗长的仪式。把我撒在嵊泗以东的海里，和老周在同一片海上。你们好好吃饭，好好过日子，就是我最想看到的事。',
        burialRegion: '浙江舟山 · 嵊泗以东海域',
        burialType: '自然山海',
        burialNote: '不保留骨灰盒，不设墓碑。若当日风浪大，改期即可，不必勉强。',
        visibility: 'public',
        lights: 128,
        favorite: false,
        createdAt: '2026-10-28T09:20:00.000Z',
        updatedAt: '2026-10-28T09:20:00.000Z'
      },
      {
        id: 'wish_seed_letters',
        title: '给女儿留下的十二封信',
        category: '想说的话',
        authorName: '周叙白',
        relation: '本人',
        anonymous: false,
        story:
          '做了一辈子编辑，习惯在稿纸边角写批注。妻子离开得早，女儿是我一手带大的。她小时候总趴在我的书桌边问：爸爸，你为什么老在纸上写字？我说，因为有些话，写下来才不会跑掉。\n\n去年查出病以后，我写了十二封信。每年一封，交给她舅舅保管。我跟他说，不要一次全给，也不要挑她最忙的时候给。等她需要一个拥抱的时候，再拆一封。\n\n信里没什么大道理。第一封写的是她六岁那年掉了一颗门牙，哭着说再也不要去学校；最后一封只写了一句：爸爸这辈子最幸运的事，是做过你的爸爸。\n\n我希望葬在太湖边那片纪念林里，选一棵普通的银杏。秋天叶子黄的时候，她如果愿意，就来坐坐。不用带香烛，带一本书就好。',
        wish:
          '十二封信按年份交给女儿，等她需要的时候再拆开。骨灰树葬，选一棵普通银杏，不刻名字，不办酒席。',
        burialRegion: '江苏苏州 · 太湖边纪念林',
        burialType: '纪念林 / 树葬',
        burialNote: '树葬，不设独立墓碑。若纪念林政策变化，就近找一处能种树的普通林地即可。',
        visibility: 'family',
        lights: 46,
        favorite: false,
        createdAt: '2026-10-12T14:05:00.000Z',
        updatedAt: '2026-10-16T10:30:00.000Z'
      },
      {
        id: 'wish_seed_bus',
        title: '一个公交车司机的身后清单',
        category: '身后事务',
        authorName: '陈砚舟',
        relation: '本人',
        anonymous: true,
        story:
          '开 42 路开了二十一年。线路不长，从老火车站到城南医院，一共十八站。哪一站早上老人多，哪一站放学时孩子多，我闭着眼也知道。\n\n我这人怕麻烦别人，所以趁还清醒，把该交代的都写清楚。车钥匙交给徒弟小罗，工具箱留给楼下邻居家的孩子，他喜欢修东西。存款分成三份：一份给妹妹，一份捐给母校的图书馆，一份留着，算是我没去成的西北。\n\n器官能捐就捐，不能捐就简单火化。不要放哀乐，放我车上常听的那盘磁带就行。乘客们不用知道我是谁，日子照常过，车照常开。\n\n我这辈子没去过敦煌。如果你们谁去，替我看看鸣沙山。听说风一吹，沙子会响。',
        wish:
          '不设灵堂，不通知太多人。能捐的器官都捐，剩下的简单火化。别给乘客添麻烦，42 路照常发车就好。',
        burialRegion: '四川成都 · 暂未决定',
        burialType: '尚未决定',
        burialNote: '如果妹妹坚持要有个地方，就选一处能看见公交车经过的坡地。',
        visibility: 'public',
        lights: 73,
        favorite: false,
        createdAt: '2026-09-30T08:10:00.000Z',
        updatedAt: '2026-09-30T08:10:00.000Z'
      },
      {
        id: 'wish_seed_osmanthus',
        title: '想葬在一棵桂花树下',
        category: '纪念方式',
        authorName: '沈望舒',
        relation: '本人',
        anonymous: false,
        story:
          '开花店的第七年，我还是最喜欢秋天。桂花乌龙要用刚开的金桂，香气才留得住。每年这个时候，店里都像被谁悄悄打翻了一罐蜜。\n\n我没什么宏大的愿望。只是不想被安排成一场沉闷的告别：黑白照片、循环的哀乐、所有人低声说话。如果那一天真的来了，请用我三十岁生日那张穿绿裙子的照片。朋友们来的时候，放我们循环了一整个夏天的歌，想笑就笑，想哭就哭。\n\n如果非要有个地方，就找一棵桂花树。不用买很贵的墓地，也不用刻很长的碑文。十月开花的时候，谁路过都能闻到。\n\n这句话我只写在这里：谢谢你们让我这一生，闻过这么好的秋天。',
        wish:
          '用穿绿裙子的照片，放那首夏天的歌。骨灰埋在一棵桂花树下，不立碑。每年十月，记得来闻一闻花香。',
        burialRegion: '浙江杭州 · 城西一处纪念林',
        burialType: '纪念林 / 树葬',
        burialNote: '希望是能开花的桂花树。若找不到合适的地方，就把骨灰撒在常去的山坡上。',
        visibility: 'private',
        lights: 9,
        favorite: true,
        createdAt: '2026-09-18T16:40:00.000Z',
        updatedAt: '2026-09-18T16:40:00.000Z'
      }
    ];
  }

  function persist(list) {
    memory = list;
    try {
      window.localStorage.setItem(KEY, JSON.stringify(list));
      return true;
    } catch (error) {
      return false;
    }
  }

  function read() {
    try {
      var raw = window.localStorage.getItem(KEY);
      if (raw === null) {
        var initial = seedWishes();
        persist(initial);
        return initial;
      }
      var parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
      if (parsed && Array.isArray(parsed.wishes)) return parsed.wishes;
      return [];
    } catch (error) {
      if (!memory) memory = seedWishes();
      return memory.slice();
    }
  }

  function normalize(input) {
    var source = input && typeof input === 'object' ? input : {};
    var category = CATEGORIES.indexOf(source.category) >= 0 ? source.category : '想说的话';
    var relation = RELATIONS.indexOf(source.relation) >= 0 ? source.relation : '本人';
    var burialType = BURIAL_TYPES.indexOf(source.burialType) >= 0 ? source.burialType : '尚未决定';
    var visibility = VISIBILITY[source.visibility] ? source.visibility : 'private';
    var createdAt = source.createdAt || nowISO();
    return {
      id: String(source.id || uid()),
      title: clean(source.title).slice(0, 60),
      category: category,
      authorName: clean(source.authorName).slice(0, 24) || '一位登记人',
      relation: relation,
      anonymous: Boolean(source.anonymous),
      story: clean(source.story).slice(0, 5000),
      wish: clean(source.wish).slice(0, 800),
      burialRegion: clean(source.burialRegion).slice(0, 80),
      burialType: burialType,
      burialNote: clean(source.burialNote).slice(0, 500),
      visibility: visibility,
      lights: Math.max(0, parseInt(source.lights, 10) || 0),
      favorite: Boolean(source.favorite),
      createdAt: createdAt,
      updatedAt: source.updatedAt || createdAt
    };
  }

  function getAll() {
    return read().map(normalize).sort(function (a, b) {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  function getById(id) {
    if (!id) return null;
    var list = read();
    for (var i = 0; i < list.length; i += 1) {
      if (list[i].id === id) return normalize(list[i]);
    }
    return null;
  }

  function save(input) {
    var list = read();
    var now = nowISO();
    var index = -1;
    for (var i = 0; i < list.length; i += 1) {
      if (list[i].id === input.id) {
        index = i;
        break;
      }
    }
    var item;
    if (index >= 0) {
      item = normalize(Object.assign({}, list[index], input, { updatedAt: now }));
      list[index] = item;
    } else {
      item = normalize(Object.assign({}, input, { createdAt: input.createdAt || now, updatedAt: now }));
      list.unshift(item);
    }
    persist(list);
    return item;
  }

  function remove(id) {
    var list = read().filter(function (wish) {
      return wish.id !== id;
    });
    persist(list);
    return list.length;
  }

  function toggleFavorite(id) {
    var list = read();
    var result = null;
    list.forEach(function (wish) {
      if (wish.id === id) {
        wish.favorite = !wish.favorite;
        result = wish.favorite;
      }
    });
    persist(list);
    return result;
  }

  function readLights() {
    try {
      var raw = window.localStorage.getItem(LIGHTS_KEY);
      var parsed = JSON.parse(raw || '[]');
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      return [];
    }
  }

  function writeLights(list) {
    try {
      window.localStorage.setItem(LIGHTS_KEY, JSON.stringify(list));
    } catch (error) {
      return false;
    }
    return true;
  }

  function hasLit(id) {
    return readLights().indexOf(id) >= 0;
  }

  function lightCount(wish) {
    if (!wish) return 0;
    return (wish.lights || 0) + (hasLit(wish.id) ? 1 : 0);
  }

  function lightWish(id) {
    if (!getById(id)) return { added: false, count: 0 };
    var lit = readLights();
    if (lit.indexOf(id) >= 0) {
      return { added: false, count: lightCount(getById(id)) };
    }
    lit.push(id);
    writeLights(lit);
    return { added: true, count: lightCount(getById(id)) };
  }

  function stats() {
    var list = getAll();
    var lit = readLights();
    var regions = {};
    var totalLights = 0;
    var stories = 0;
    list.forEach(function (wish) {
      if (wish.burialRegion) {
        var region = String(wish.burialRegion).split(/[·,，/]/)[0].trim();
        if (region) regions[region] = true;
      }
      if (wish.story && wish.story.length > 20) stories += 1;
      totalLights += (wish.lights || 0) + (lit.indexOf(wish.id) >= 0 ? 1 : 0);
    });
    return {
      total: list.length,
      stories: stories,
      regions: Object.keys(regions).length,
      lights: totalLights,
      publicCount: list.filter(function (w) {
        return w.visibility === 'public';
      }).length,
      favoriteCount: list.filter(function (w) {
        return w.favorite;
      }).length
    };
  }

  function getPublic(limit) {
    var list = getAll().filter(function (wish) {
      return wish.visibility === 'public';
    });
    return typeof limit === 'number' ? list.slice(0, limit) : list;
  }

  function formatDate(iso, compact) {
    var date = new Date(iso);
    if (isNaN(date.getTime())) return '日期未知';
    if (compact) {
      return date.getFullYear() + '.' + (date.getMonth() + 1) + '.' + date.getDate();
    }
    return date.getFullYear() + '年' + (date.getMonth() + 1) + '月' + date.getDate() + '日';
  }

  function excerpt(text, limit) {
    var value = clean(text).replace(/\s+/g, ' ');
    var max = limit || 90;
    return value.length > max ? value.slice(0, max) + '…' : value;
  }

  function escapeHTML(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char];
    });
  }

  function highlight(text, query) {
    var safe = escapeHTML(text);
    var needle = escapeHTML(clean(query));
    if (!needle) return safe;
    var pattern = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    try {
      return safe.replace(new RegExp('(' + pattern + ')', 'gi'), '<mark>$1</mark>');
    } catch (error) {
      return safe;
    }
  }

  function displayAuthor(wish) {
    if (!wish) return '一位登记人';
    return wish.anonymous ? '一位不愿具名的登记人' : wish.authorName;
  }

  function exportData() {
    return JSON.stringify(
      {
        version: VERSION,
        app: '时光留痕 · 生前心愿纪念平台',
        exportedAt: nowISO(),
        wishes: getAll()
      },
      null,
      2
    );
  }

  function importData(text) {
    var parsed = JSON.parse(text);
    var incoming = Array.isArray(parsed) ? parsed : parsed && Array.isArray(parsed.wishes) ? parsed.wishes : null;
    if (!incoming) throw new Error('文件格式不正确，未找到心愿数据。');
    var current = getAll();
    var map = {};
    current.forEach(function (wish) {
      map[wish.id] = wish;
    });
    var added = 0;
    var updated = 0;
    var skipped = 0;
    incoming.forEach(function (item) {
      if (!item || !clean(item.title)) {
        skipped += 1;
        return;
      }
      var wish = normalize(item);
      if (map[wish.id]) {
        map[wish.id] = Object.assign({}, map[wish.id], wish);
        updated += 1;
      } else {
        map[wish.id] = wish;
        added += 1;
      }
    });
    var merged = Object.keys(map).map(function (key) {
      return map[key];
    });
    persist(merged);
    return { added: added, updated: updated, skipped: skipped, total: merged.length };
  }

  function getDraft() {
    try {
      var raw = window.localStorage.getItem(DRAFT_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.savedAt ? parsed : null;
    } catch (error) {
      return null;
    }
  }

  function saveDraft(values) {
    var payload = Object.assign({}, values, { savedAt: nowISO() });
    try {
      window.localStorage.setItem(DRAFT_KEY, JSON.stringify(payload));
      return payload;
    } catch (error) {
      return null;
    }
  }

  function clearDraft() {
    try {
      window.localStorage.removeItem(DRAFT_KEY);
    } catch (error) {
      return false;
    }
    return true;
  }

  function resetDemo() {
    var list = seedWishes();
    persist(list);
    clearDraft();
    writeLights([]);
    return list.length;
  }

  function clearAll() {
    persist([]);
    clearDraft();
    writeLights([]);
  }

  window.TraceStore = {
    CATEGORIES: CATEGORIES,
    RELATIONS: RELATIONS,
    BURIAL_TYPES: BURIAL_TYPES,
    VISIBILITY: VISIBILITY,
    getAll: getAll,
    getById: getById,
    getPublic: getPublic,
    save: save,
    remove: remove,
    toggleFavorite: toggleFavorite,
    stats: stats,
    formatDate: formatDate,
    excerpt: excerpt,
    escapeHTML: escapeHTML,
    highlight: highlight,
    displayAuthor: displayAuthor,
    lightCount: lightCount,
    hasLit: hasLit,
    lightWish: lightWish,
    exportData: exportData,
    importData: importData,
    getDraft: getDraft,
    saveDraft: saveDraft,
    clearDraft: clearDraft,
    resetDemo: resetDemo,
    clearAll: clearAll,
    uid: uid
  };
})();