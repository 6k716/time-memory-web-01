(function () {
  'use strict';

  var Store = window.TraceStore;
  var UI = window.TraceUI;
  var esc = Store.escapeHTML;

  function animateNumber(node, target) {
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion || target <= 0) {
      node.textContent = String(target);
      return;
    }
    var startedAt = null;
    var duration = 900;
    function tick(timestamp) {
      if (startedAt === null) startedAt = timestamp;
      var progress = Math.min(1, (timestamp - startedAt) / duration);
      var eased = 1 - Math.pow(1 - progress, 3);
      node.textContent = String(Math.round(target * eased));
      if (progress < 1) window.requestAnimationFrame(tick);
    }
    window.requestAnimationFrame(tick);
  }

  function renderStats() {
    var data = Store.stats();
    document.querySelectorAll('[data-stat]').forEach(function (node) {
      animateNumber(node, data[node.getAttribute('data-stat')] || 0);
    });
  }

  function cardHTML(wish, small) {
    return (
      '<a class="feature-card ' +
      (small ? 'feature-small' : 'feature-large') +
      '" href="detail.html?id=' +
      encodeURIComponent(wish.id) +
      '">' +
      '<div class="feature-top"><span class="tag">' +
      esc(wish.category) +
      '</span><span class="feature-date">' +
      Store.formatDate(wish.createdAt, true) +
      '</span></div>' +
      '<h3>' +
      esc(wish.title) +
      '</h3>' +
      '<p>' +
      esc(Store.excerpt(wish.story, 150)) +
      '</p>' +
      '<div class="feature-foot"><span>' +
      esc(Store.displayAuthor(wish)) +
      ' · ' +
      esc(wish.burialRegion || '地点尚未决定') +
      '</span><span class="feature-arrow"><svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>' +
      '</a>'
    );
  }

  function emptyCardHTML() {
    return (
      '<div class="feature-card feature-empty" style="grid-column:1 / -1">' +
      '<h3>这一页，还空着。</h3>' +
      '<p>还没有公开的心愿。你可以先写下一份，并选择「公开展示」，让故事出现在这里。</p>' +
      '<a class="btn btn-ghost" href="submit.html">登记一份心愿</a>' +
      '</div>'
    );
  }

  function renderFeatured() {
    var grid = document.getElementById('featuredGrid');
    if (!grid) return;
    var items = Store.getPublic(2);
    var html = items.length ? items.map(function (wish, index) {
      return cardHTML(wish, index > 0);
    }).join('') : emptyCardHTML();
    if (items.length === 1) {
      html +=
        '<a class="feature-card feature-small feature-empty" href="submit.html">' +
        '<h3>这一格，留给你的故事。</h3>' +
        '<p>一份心愿，一段经历，一句想说的话。十分钟，就可以留下。</p>' +
        '<span class="feature-arrow" style="margin-top:auto"><svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span>' +
        '</a>';
    }
    grid.innerHTML = html;
  }

  renderStats();
  renderFeatured();

  if (UI && typeof UI.initReveal === 'function') {
    UI.initReveal();
  }
})();