(function () {
  'use strict';

  var Store = window.TraceStore;
  var UI = window.TraceUI;
  var esc = Store.escapeHTML;

  var listEl = document.getElementById('wishList');
  var emptyEl = document.getElementById('emptyState');
  var emptyTitle = document.getElementById('emptyTitle');
  var emptyText = document.getElementById('emptyText');
  var searchInput = document.getElementById('searchInput');
  var categoryFilter = document.getElementById('categoryFilter');
  var visibilityFilter = document.getElementById('visibilityFilter');
  var sortFilter = document.getElementById('sortFilter');
  var favoriteFilter = document.getElementById('favoriteFilter');
  var resultText = document.getElementById('resultText');
  var clearFilters = document.getElementById('clearFilters');
  var statTotal = document.getElementById('statTotal');
  var statPublic = document.getElementById('statPublic');
  var statFavorite = document.getElementById('statFavorite');
  var dataPanel = document.getElementById('dataPanel');
  var openData = document.getElementById('openData');
  var importFile = document.getElementById('importFile');

  if (!listEl) return;

  var state = {
    query: '',
    category: 'all',
    visibility: 'all',
    sort: 'new',
    favoriteOnly: false
  };

  function favIcon(filled) {
    return (
      '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2.6l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L2.8 7.9l5-.7L10 2.6Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round" fill="' +
      (filled ? 'currentColor' : 'none') +
      '"/></svg>'
    );
  }

  function visibleLabel(wish) {
    var item = Store.VISIBILITY[wish.visibility];
    return item ? item.label : '仅自己可见';
  }

  function filteredWishes() {
    var query = state.query.trim().toLowerCase();
    var list = Store.getAll();

    if (state.category !== 'all') {
      list = list.filter(function (wish) {
        return wish.category === state.category;
      });
    }
    if (state.visibility !== 'all') {
      list = list.filter(function (wish) {
        return wish.visibility === state.visibility;
      });
    }
    if (state.favoriteOnly) {
      list = list.filter(function (wish) {
        return wish.favorite;
      });
    }
    if (query) {
      list = list.filter(function (wish) {
        var haystack = [wish.title, wish.story, wish.wish, wish.authorName, wish.burialRegion, wish.category]
          .join(' ')
          .toLowerCase();
        return haystack.indexOf(query) >= 0;
      });
    }

    if (state.sort === 'old') {
      list.sort(function (a, b) {
        return new Date(a.createdAt) - new Date(b.createdAt);
      });
    } else if (state.sort === 'title') {
      list.sort(function (a, b) {
        return String(a.title).localeCompare(String(b.title), 'zh-Hans-CN');
      });
    } else {
      list.sort(function (a, b) {
        return new Date(b.createdAt) - new Date(a.createdAt);
      });
    }
    return list;
  }

  function renderStats() {
    var data = Store.stats();
    if (statTotal) statTotal.textContent = String(data.total);
    if (statPublic) statPublic.textContent = String(data.publicCount);
    if (statFavorite) statFavorite.textContent = String(data.favoriteCount);
  }

  function rowHTML(wish) {
    return (
      '<article class="wish-row" data-id="' +
      esc(wish.id) +
      '">' +
      '<div class="wish-row-main">' +
      '<div class="row-meta">' +
      '<span class="tag">' +
      esc(wish.category) +
      '</span>' +
      '<span class="vis-badge vis-' +
      esc(wish.visibility) +
      '">' +
      esc(visibleLabel(wish)) +
      '</span>' +
      '<span class="row-date">' +
      Store.formatDate(wish.createdAt) +
      '</span>' +
      '</div>' +
      '<h2><a href="detail.html?id=' +
      encodeURIComponent(wish.id) +
      '">' +
      Store.highlight(wish.title, state.query) +
      '</a></h2>' +
      '<p class="row-excerpt">' +
      Store.highlight(Store.excerpt(wish.story || wish.wish, 120), state.query) +
      '</p>' +
      '<div class="row-author">' +
      esc(Store.displayAuthor(wish)) +
      ' · ' +
      esc(wish.relation) +
      '登记 · ' +
      esc(wish.burialRegion || '安葬地点尚未决定') +
      '</div>' +
      '</div>' +
      '<div class="row-side">' +
      '<button class="icon-btn fav' +
      (wish.favorite ? ' is-on' : '') +
      '" type="button" data-action="fav" aria-label="' +
      (wish.favorite ? '取消收藏' : '收藏这份心愿') +
      '" aria-pressed="' +
      String(Boolean(wish.favorite)) +
      '">' +
      favIcon(wish.favorite) +
      '</button>' +
      '<a class="btn-quiet" href="detail.html?id=' +
      encodeURIComponent(wish.id) +
      '">查看</a>' +
      '<a class="btn-quiet" href="submit.html?id=' +
      encodeURIComponent(wish.id) +
      '">编辑</a>' +
      '<button class="btn-quiet danger" type="button" data-action="delete">删除</button>' +
      '</div>' +
      '</article>'
    );
  }

  function render() {
    var all = Store.getAll();
    var items = filteredWishes();
    var hasFilter =
      state.query.trim() !== '' ||
      state.category !== 'all' ||
      state.visibility !== 'all' ||
      state.favoriteOnly;

    listEl.innerHTML = items.map(rowHTML).join('');
    listEl.hidden = items.length === 0;
    emptyEl.hidden = items.length > 0;

    var emptyCta = emptyEl.querySelector('.btn');
    if (emptyCta) {
      emptyCta.textContent = all.length === 0 ? '登记第一份心愿' : '登记一份新心愿';
    }

    if (!items.length) {
      if (all.length === 0) {
        emptyTitle.textContent = '还没有登记过心愿';
        emptyText.textContent = '这里会安静地保存你写下的故事与托付。可以先从一份简短的心愿开始。';
      } else if (state.favoriteOnly && !hasFilterOthers()) {
        emptyTitle.textContent = '还没有收藏的心愿';
        emptyText.textContent = '在档案列表里点击星标，就能把想反复阅读的故事留在这里。';
      } else {
        emptyTitle.textContent = '没有符合条件的心愿';
        emptyText.textContent = '换一个关键词，或者清除筛选后再看看。';
      }
    }

    if (resultText) {
      resultText.textContent = hasFilter ? '找到 ' + items.length + ' 份心愿' : '展示全部 ' + items.length + ' 份心愿';
    }
    if (clearFilters) clearFilters.hidden = !hasFilter;

    favoriteFilter.classList.toggle('is-on', state.favoriteOnly);
    favoriteFilter.setAttribute('aria-pressed', String(state.favoriteOnly));

    renderStats();
  }

  function hasFilterOthers() {
    return state.query.trim() !== '' || state.category !== 'all' || state.visibility !== 'all';
  }

  function resetFilters() {
    state.query = '';
    state.category = 'all';
    state.visibility = 'all';
    state.sort = 'new';
    state.favoriteOnly = false;
    if (searchInput) searchInput.value = '';
    if (categoryFilter) categoryFilter.value = 'all';
    if (visibilityFilter) visibilityFilter.value = 'all';
    if (sortFilter) sortFilter.value = 'new';
    render();
  }

  if (searchInput) {
    searchInput.addEventListener('input', function () {
      state.query = searchInput.value;
      render();
    });
  }

  if (categoryFilter) {
    categoryFilter.addEventListener('change', function () {
      state.category = categoryFilter.value;
      render();
    });
  }

  if (visibilityFilter) {
    visibilityFilter.addEventListener('change', function () {
      state.visibility = visibilityFilter.value;
      render();
    });
  }

  if (sortFilter) {
    sortFilter.addEventListener('change', function () {
      state.sort = sortFilter.value;
      render();
    });
  }

  if (favoriteFilter) {
    favoriteFilter.addEventListener('click', function () {
      state.favoriteOnly = !state.favoriteOnly;
      render();
    });
  }

  if (clearFilters) {
    clearFilters.addEventListener('click', resetFilters);
  }

  listEl.addEventListener('click', function (event) {
    var button = event.target.closest('[data-action]');
    if (!button) return;
    var row = button.closest('.wish-row');
    if (!row) return;
    var id = row.getAttribute('data-id');
    var wish = Store.getById(id);
    if (!wish) return;

    if (button.getAttribute('data-action') === 'fav') {
      var on = Store.toggleFavorite(id);
      button.classList.toggle('is-on', Boolean(on));
      button.setAttribute('aria-pressed', String(Boolean(on)));
      button.setAttribute('aria-label', on ? '取消收藏' : '收藏这份心愿');
      var svgPath = button.querySelector('path');
      if (svgPath) svgPath.setAttribute('fill', on ? 'currentColor' : 'none');
      renderStats();
      if (state.favoriteOnly && !on) render();
      UI.toast(on ? '已加入收藏' : '已取消收藏');
      return;
    }

    if (button.getAttribute('data-action') === 'delete') {
      UI.confirm({
        title: '删除这份心愿？',
        message: '「' + wish.title + '」将从本机档案中移除，且无法恢复。建议先在下方“数据管理”中导出备份。',
        confirmText: '确认删除',
        danger: true
      }).then(function (confirmed) {
        if (!confirmed) return;
        Store.remove(id);
        UI.toast('已删除这份心愿');
        render();
      });
    }
  });

  if (openData && dataPanel) {
    openData.addEventListener('click', function () {
      dataPanel.open = true;
      dataPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  var exportBtn = document.getElementById('exportBtn');
  if (exportBtn) {
    exportBtn.addEventListener('click', function () {
      var stamp = new Date();
      var name =
        '时光留痕-心愿备份-' +
        stamp.getFullYear() +
        String(stamp.getMonth() + 1).padStart(2, '0') +
        String(stamp.getDate()).padStart(2, '0') +
        '.json';
      UI.download(name, Store.exportData());
      UI.toast('备份文件已开始下载');
    });
  }

  if (importFile) {
    importFile.addEventListener('change', function () {
      var file = importFile.files && importFile.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var result = Store.importData(String(reader.result || ''));
          UI.toast('导入完成：新增 ' + result.added + ' 份，更新 ' + result.updated + ' 份');
          render();
        } catch (error) {
          UI.toast(error.message || '导入失败，请检查文件格式', 'error');
        }
        importFile.value = '';
      };
      reader.onerror = function () {
        UI.toast('读取文件失败，请重试', 'error');
        importFile.value = '';
      };
      reader.readAsText(file, 'utf-8');
    });
  }

  var resetBtn = document.getElementById('resetBtn');
  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      UI.confirm({
        title: '恢复示例数据？',
        message: '当前全部记录（包括你新建的心愿）会被四份示例数据替换。建议先导出备份。',
        confirmText: '恢复示例',
        danger: true
      }).then(function (confirmed) {
        if (!confirmed) return;
        var count = Store.resetDemo();
        resetFilters();
        UI.toast('已恢复 ' + count + ' 份示例数据');
      });
    });
  }

  var clearBtn = document.getElementById('clearBtn');
  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      UI.confirm({
        title: '清空全部数据？',
        message: '所有心愿、收藏与点亮记录都会从本机消失，且无法恢复。请先确认已导出备份。',
        confirmText: '清空全部',
        danger: true
      }).then(function (confirmed) {
        if (!confirmed) return;
        Store.clearAll();
        resetFilters();
        UI.toast('本机数据已清空');
      });
    });
  }

  var importLabel = document.querySelector('label[for="importFile"]');
  if (importLabel) {
    importLabel.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        importFile.click();
      }
    });
  }

  render();
})();