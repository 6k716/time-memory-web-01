(function () {
  'use strict';

  var Store = window.TraceStore;
  var UI = window.TraceUI;
  var esc = Store.escapeHTML;

  var params = new URLSearchParams(window.location.search);
  var id = params.get('id');
  var wish = Store.getById(id);
  var article = document.getElementById('detailArticle');
  var notFound = document.getElementById('notFound');
  var relatedSection = document.getElementById('relatedSection');
  var relatedGrid = document.getElementById('relatedGrid');
  var breadcrumb = document.getElementById('breadcrumb');

  function showNotFound() {
    if (article) article.hidden = true;
    if (relatedSection) relatedSection.hidden = true;
    if (notFound) notFound.hidden = false;
    document.title = '未找到心愿 · 时光留痕';
  }

  if (!wish) {
    showNotFound();
    return;
  }

  document.title = wish.title + ' · 时光留痕';

  if (breadcrumb) {
    var last = breadcrumb.lastElementChild;
    if (last) {
      last.textContent = wish.title.length > 18 ? wish.title.slice(0, 18) + '…' : wish.title;
    }
  }

  function registrationNumber() {
    var all = Store.getAll();
    var index = -1;
    for (var i = 0; i < all.length; i += 1) {
      if (all[i].id === wish.id) {
        index = i;
        break;
      }
    }
    var value = index >= 0 ? index + 1 : 1;
    return '#' + String(value).padStart(4, '0');
  }

  function paragraphs(text) {
    var value = String(text || '').trim();
    if (!value) return '<p>这份心愿还没有留下故事。</p>';
    return value
      .split(/\n{2,}/)
      .map(function (part) {
        return '<p>' + esc(part) + '</p>';
      })
      .join('');
  }

  var visibility = Store.VISIBILITY[wish.visibility] || Store.VISIBILITY.private;
  var author = Store.displayAuthor(wish);
  var initial = wish.anonymous ? '匿' : String(wish.authorName || '心').slice(0, 1);
  var relationLabel = wish.relation === '本人' ? '本人登记' : wish.relation + '代填';
  var isPrivate = wish.visibility !== 'public';
  var lit = Store.hasLit(wish.id);
  var lightCount = Store.lightCount(wish);

  var privacyHTML = isPrivate
    ? '<div class="privacy-note">' +
      '<svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="4.5" y="8.5" width="11" height="8" rx="1.5" stroke="currentColor" stroke-width="1.3"/><path d="M7 8.5V6.8a3 3 0 0 1 6 0v1.7" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>' +
      '<span>这份心愿的可见范围是「' +
      esc(visibility.label) +
      '」。正式产品中，只有获得授权的家人或登记人登录后才能查看；当前原型的数据仅保存在本机。</span>' +
      '</div>'
    : '';

  article.innerHTML =
    '<header class="detail-head">' +
    '<div class="detail-eyebrow">' +
    '<span class="tag">' +
    esc(wish.category) +
    '</span>' +
    '<span class="vis-badge vis-' +
    esc(wish.visibility) +
    '">' +
    esc(visibility.label) +
    '</span>' +
    '</div>' +
    '<h1>' +
    esc(wish.title) +
    '</h1>' +
    '<p class="detail-lede">' +
    esc(wish.wish) +
    '</p>' +
    '<div class="byline">' +
    '<span class="avatar-initial" aria-hidden="true">' +
    esc(initial) +
    '</span>' +
    '<div><strong>' +
    esc(author) +
    '</strong><span>' +
    esc(relationLabel) +
    ' · ' +
    Store.formatDate(wish.createdAt) +
    '</span></div>' +
    '</div>' +
    '</header>' +
    '<div class="detail-body">' +
    '<div class="detail-main">' +
    privacyHTML +
    '<section class="prose">' +
    '<h2>留下的故事</h2>' +
    paragraphs(wish.story) +
    '</section>' +
    '<section class="wish-block">' +
    '<h2>我的心愿</h2>' +
    '<p>' +
    esc(wish.wish) +
    '</p>' +
    '</section>' +
    '<section class="burial-block">' +
    '<h2>安葬地点偏好</h2>' +
    '<dl class="meta-list">' +
    '<div><dt>意向地区</dt><dd>' +
    esc(wish.burialRegion || '尚未留下地点偏好') +
    '</dd></div>' +
    '<div><dt>场所类型</dt><dd>' +
    esc(wish.burialType || '尚未决定') +
    '</dd></div>' +
    '<div><dt>补充说明</dt><dd>' +
    esc(wish.burialNote || '没有更多补充') +
    '</dd></div>' +
    '</dl>' +
    '<p class="burial-note">安葬偏好只是一份留给家人的参考，不构成任何真实服务预约或交易。</p>' +
    '</section>' +
    '</div>' +
    '<aside class="detail-aside">' +
    '<div class="aside-card">' +
    '<p class="aside-label">为这份心愿点一盏灯</p>' +
    '<div class="light-count"><span id="lightCount">' +
    lightCount +
    '</span><small>次微光</small></div>' +
    '<button class="btn btn-primary" type="button" id="lightBtn"' +
    (lit ? ' disabled' : '') +
    '>' +
    (lit ? '已经点亮' : '点亮一盏') +
    '</button>' +
    '<p class="light-hint">每台设备可为同一份心愿点亮一次 · 仅记录在本机</p>' +
    '</div>' +
    '<div class="aside-card">' +
    '<p class="aside-label">档案信息</p>' +
    '<dl class="meta-list">' +
    '<div><dt>登记编号</dt><dd>' +
    registrationNumber() +
    '</dd></div>' +
    '<div><dt>登记人</dt><dd>' +
    esc(author) +
    '</dd></div>' +
    '<div><dt>可见范围</dt><dd>' +
    esc(visibility.label) +
    '</dd></div>' +
    '<div><dt>最近更新</dt><dd>' +
    Store.formatDate(wish.updatedAt) +
    '</dd></div>' +
    '</dl>' +
    '</div>' +
    '<div class="aside-actions">' +
    '<button class="btn-quiet" type="button" data-action="share">分享链接</button>' +
    '<button class="btn-quiet" type="button" data-action="print">打印此页</button>' +
    '<a class="btn-quiet" href="submit.html?id=' +
    encodeURIComponent(wish.id) +
    '">编辑</a>' +
    '<button class="btn-quiet danger" type="button" data-action="delete">删除</button>' +
    '</div>' +
    '</aside>' +
    '</div>';

  var lightBtn = document.getElementById('lightBtn');
  var lightCountEl = document.getElementById('lightCount');

  if (lightBtn) {
    lightBtn.addEventListener('click', function () {
      var result = Store.lightWish(wish.id);
      if (!result.added) {
        lightBtn.disabled = true;
        lightBtn.textContent = '已经点亮';
        UI.toast('你已经为这份心愿点过灯了');
        return;
      }
      if (lightCountEl) lightCountEl.textContent = String(result.count);
      lightBtn.disabled = true;
      lightBtn.textContent = '已经点亮';
      UI.toast('一盏微光已经亮起');
    });
  }

  article.addEventListener('click', function (event) {
    var button = event.target.closest('[data-action]');
    if (!button) return;
    var action = button.getAttribute('data-action');

    if (action === 'share') {
      UI.copyText(window.location.href)
        .then(function () {
          UI.toast('链接已复制到剪贴板');
        })
        .catch(function () {
          UI.toast('复制失败，请手动复制地址栏链接', 'error');
        });
      return;
    }

    if (action === 'print') {
      window.print();
      return;
    }

    if (action === 'delete') {
      UI.confirm({
        title: '删除这份心愿？',
        message: '「' + wish.title + '」将从本机档案中移除，且无法恢复。建议先在心愿档案中导出备份。',
        confirmText: '确认删除',
        danger: true
      }).then(function (confirmed) {
        if (!confirmed) return;
        Store.remove(wish.id);
        window.location.href = 'wishes.html';
      });
    }
  });

  function relatedHTML(item) {
    return (
      '<a class="related-card" href="detail.html?id=' +
      encodeURIComponent(item.id) +
      '">' +
      '<span class="tag">' +
      esc(item.category) +
      '</span>' +
      '<h3>' +
      esc(item.title) +
      '</h3>' +
      '<p>' +
      esc(Store.excerpt(item.story || item.wish, 90)) +
      '</p>' +
      '<div class="related-foot">' +
      esc(Store.displayAuthor(item)) +
      ' · ' +
      Store.formatDate(item.createdAt) +
      '</div>' +
      '</a>'
    );
  }

  var pool = Store.getAll().filter(function (item) {
    return item.id !== wish.id && item.visibility === 'public';
  });
  var sameCategory = pool.filter(function (item) {
    return item.category === wish.category;
  });
  var others = pool.filter(function (item) {
    return item.category !== wish.category;
  });
  var related = sameCategory.concat(others).slice(0, 2);

  if (related.length && relatedGrid) {
    relatedGrid.innerHTML = related.map(relatedHTML).join('');
    relatedSection.hidden = false;
  }
})();